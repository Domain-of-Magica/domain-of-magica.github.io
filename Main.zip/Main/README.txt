======== HOW TO PLAY ========
There's 2 clients you can play with, they are different performance-wise.


=== AIR Client
* Launch "Domain of Magica.exe" 


=== Flash Client
* Open the "Flash" folder
* Launch "flashplayer18.exe"
* Click "File", then "Open..." in top left corner of the opened window
* Paste this link into the Location: https://domain-of-magica.github.io/WebMain.swf
* Click OK

The "flashplayer18.exe" file can be moved to your desktop if you wish.


========= TROUBLESHOOTING GUIDE =========
If upon launching the game something goes wrong, like just a black screen 
with "Loading..." text, then try following these steps.


=== Move the game folder to Desktop
Try moving the entire game folder to your Desktop, and then 
try launching it from there.


=== Download Visual C++ Runtime
Download them from these two links:
https://aka.ms/vs/16/release/vc_redist.x64.exe
https://aka.ms/vs/16/release/vc_redist.x86.exe

Try opening the game again, and see if it works.


=== Add C: Disk as Flash Trusted Folder
Open the "Flash" folder and Copy "winetrust.cfg" file, you will have to paste it later.

Open File Explorer and click on the top bar that says the current folder you're in.
Type %AppData% in there and press Enter.
You should be in AppData/Roaming folder now.
`C:/Users/(Your user name)/AppData/Roaming`

Find Macromedia folder, if it doesn't exist, create it.
Then go to this directory: 
`Macromedia/Flash Player/#Security/FlashPlayerTrust`
And again, if any of these folders don't exist, simply create them.
You should end up here:
`C:/Users/(Your user name)/AppData/Roaming/Macromedia/Flash Player/#Security/FlashPlayerTrust`

Once there, Copy and Paste "winetrust.cfg" into the directory.
Try launching the game now.


=== Add Antivirus Exception for DoM
Windows Defender might be flagging DoM as a virus because of unsigned .exe.

Open "Virus & threat protection" with Windows search.
Scroll down and click "Manage settings" under "Virus & threat protection settings".
Scroll down until you see "Exclusions", click "Add or remove exclusions".
Add the entire DoM folder as an exclusion.
Try launching the game.

